<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta http-equiv="Content-Language" content="en-us">
<meta name="description" content=""/>
<meta name="keywords" content=""/>
<link rel="shortcut icon" href="<?php echo site_url(); ?>/favicon.ico" />
<!--
   *****************************************************
   Designed by Squad Ink
   http://www.squadink.com/
   Developed by Harmonic New Media.
   http://www.harmonicnewmedia.com
   Copyright 2012. All rights reserved.
   *****************************************************
-->
<!-- TemplateBeginEditable name="doctitle" -->
<title>Be Centre</title>
<!-- TemplateEndEditable -->
<link href='http://fonts.googleapis.com/css?family=Short+Stack' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Schoolbell' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Sue+Ellen+Francisco' rel='stylesheet' type='text/css'>
<link href="<?php echo get_bloginfo("stylesheet_directory"); ?>/css/layout.css?v1" rel="stylesheet" />
<link href="<?php echo get_bloginfo("stylesheet_directory"); ?>/css/sub.css" rel="stylesheet" />
<script src="<?php echo get_bloginfo("stylesheet_directory"); ?>/js/jquery-1.6.1.min.js"></script>
<script src="<?php echo get_bloginfo("stylesheet_directory"); ?>/js/calls.js"></script>
<!--[if lt IE 9]>
  <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script>
// Animation

(function($){
    var sloganLoop;
    var currentShowing = 0;
    jQuery(document).ready(function() {
        switchImgOnHover("SupporterTop","<?php echo get_bloginfo("stylesheet_directory"); ?>/layout/SupporterTopNew.gif","<?php echo get_bloginfo("stylesheet_directory"); ?>/layout/SupporterTopAnimated.gif");
        switchImgOnHover("RocketTop","<?php echo get_bloginfo("stylesheet_directory"); ?>/layout/RocketTop.gif","<?php echo get_bloginfo("stylesheet_directory"); ?>/layout/RocketTopAnimated.gif");
        sloganLoop = setTimeout("startSloganLoop()",2000);
    });

    this.startSloganLoop = function() {
        if (currentShowing == 0) {
            $("#header-slogan1").fadeOut(2000);
            $("#header-slogan2").fadeIn(2000);
            currentShowing = 1;
        } else {
            $("#header-slogan2").fadeOut(2000);
            $("#header-slogan1").fadeIn(2000);
            currentShowing = 0;
        }

        sloganLoop = setTimeout("startSloganLoop()",8000);
    }
})(jQuery);

</script>
<!-- TemplateBeginEditable name="head" -->
<!-- TemplateEndEditable -->
<!-- TemplateParam name="id" type="text" value="" -->
<!-- TemplateParam name="class" type="text" value="" -->
</head>

<body class="@@(_document['class'])@@" id="@@(id)@@">
  <!--WRAPPERS-->
  <div id="texture">	
    <div id="cloud">
      <div id="wrapper">
        <!--HEADER-->
        <header id="header-main">
          <div id="header-rocket"><a href="<?php echo site_url(); ?>/"><img src="<?php echo get_bloginfo("stylesheet_directory"); ?>/layout/RocketTop.gif" width="480" height="354" id="RocketTop"></a></div>
          <a href="<?php echo site_url(); ?>/" id="header-logo">
            <div id="header-slogan1"></div>
            <div id="header-slogan2"></div>
          </a>
          <a href="<?php echo site_url(); ?>/supporter" id="header-supporter"><img src="<?php echo get_bloginfo("stylesheet_directory"); ?>/layout/SupporterTopNew.gif" width="254" height="250" id="SupporterTop"></a>
        </header>
        <div id="section-main">
          <!--LHS-->
          <div id="lhs-aside">
            <!--NAV-->
            <nav id="main-nav">
              <ul>
                <li id="nav-therapy"><a href="<?php echo site_url(); ?>/what-is-creative-therapy" title="What is creative therapy?"></a></li>
                <li id="nav-help"><a href="<?php echo site_url(); ?>/help" title="How we can help?"></a></li>
                <li id="nav-programs"><a href="<?php echo site_url(); ?>/programs" title="Be Centre programs"></a>
                  <ul>
                    <li id="subnav-bubs"><a href="<?php echo site_url(); ?>/programs/bubs" title="Be-bubs"></a></li>
                    <li id="subnav-kids"><a href="<?php echo site_url(); ?>/programs/kids" title="Be-kids"></a></li>
                    <li id="subnav-teens"><a href="<?php echo site_url(); ?>/programs/teens" title="Be-teens"></a></li>
                    <li id="subnav-parents"><a href="<?php echo site_url(); ?>/programs/parents" title="Be-parents"></a></li>
                  </ul>
                </li>
                <li id="nav-team"><a href="<?php echo site_url(); ?>/team" title="The team"></a>
                  <ul>
                    <li id="subnav-welcome"><a href="<?php echo site_url(); ?>/team/welcome" title="CEO's welcome"></a></li>
                    <li id="subnav-message"><a href="<?php echo site_url(); ?>/team/message" title="Founder's message"></a></li>
                    <li id="subnav-board"><a href="<?php echo site_url(); ?>/team/board" title="The board"></a></li>
                  </ul>
                </li>
                <li id="nav-contact"><a href="<?php echo site_url(); ?>/contact" title="Contact"></a></li>
                <li id="nav-news"><a href="<?php echo site_url(); ?>/news" title="News"></a></li>
                <li id="nav-publications"><a href="<?php echo site_url(); ?>/publications" title="News"></a></li>
                <li id="nav-professionals"><a href="<?php echo site_url(); ?>/professionals" title="Info for professionals"></a></li>
                <li id="nav-testimonials"><a href="<?php echo site_url(); ?>/testimonials" title="Testimonials"></a></li>
              </ul>
            </nav>
            <!--TWITTER BOX-->
            <aside id="twitter-box">
              <script charset="utf-8" src="http://widgets.twimg.com/j/2/widget.js"></script>
			  <script>
                new TWTR.Widget({
                  version: 2,
                  type: 'profile',
                  rpp: 3,
                  interval: 30000,
                  width: 190,
                  height: 290,
                  theme: {
                    shell: {
                      background: '#2b9ce8',
                      color: '#ffffff'
                    },
                    tweets: {
                      background: '#c8e8fa',
                      color: '#58595b',
                      links: '#003053'
                    }
                  },
                  features: {
                    scrollbar: false,
                    loop: false,
                    live: false,
                    behavior: 'all'
                  }
                }).render().setUser('becentre').start();
              </script>
            </aside>
          </div>
          <!--CONTENT-->
          <section id="content-wrap"><!-- TemplateBeginEditable name="mainContent" -->
            <!-- TemplateEndEditable -->
            <div class="clear"></div>
          </section>
          <div class="clear"></div>
        </div>
      </div>
      <!--FOOTER-->
      <footer id="footer-main">
	    <div id="footer-bg">
          <!--Icons-->
          <div id="icons-wraper">
            <div id="follow">
              <a href="https://twitter.com/#!/becentre" id="ico-twitter" target="_blank"></a>
              <a href="http://www.facebook.com/becentre" id="ico-facebook" target="_blank"></a>
            </div>
            <a href="mailto:?subject=Check%20this%20out%20&body=I%20visited%20Be%20Centre%20website%20and%20want%20to%20share%20it%20with%20you%20http://www.becentre.com.au" id="tell"></a>
            <div id="supporter-footer">
              <a href="<?php echo site_url(); ?>/supporter"><img src="<?php echo get_bloginfo("stylesheet_directory"); ?>/layout/SupporterBottomAnimated.gif" width="232" height="175" id="SupporterBottom"></a>
            </div>
          </div>
          <!--Nav-->
          <ul id="footer-nav">
            <li><a href="<?php echo site_url(); ?>/supporter">Be a supporter</a></li>
            <li><a href="<?php echo site_url(); ?>/what-is-creative-therapy">What is creative therapy?</a></li>
            <li><a href="<?php echo site_url(); ?>/help">How we can help</a></li>
            <li><a href="<?php echo site_url(); ?>/programs">Be Centre programs</a></li>
            <li><a href="<?php echo site_url(); ?>/team">The team</a></li>
            <li><a href="<?php echo site_url(); ?>/contact">Contact</a></li>
            <li><a href="<?php echo site_url(); ?>/news">News</a></li>
            <li><a href="<?php echo site_url(); ?>/professionals">Info for professionals</a></li>
            <li><a href="<?php echo site_url(); ?>/testimonials">Testimonials</a></li>
          </ul>
          <!--Contact-->
          <div id="footer-contact">
            <div id="newsletter-text">
              Sign up to our newsletter and receive the latest from the Be Team.
            </div>
            <form action="http://becentre.createsend.com/t/t/s/dudtr/" method="post" id="newsletter-form">
<input type="text" name="cm-dudtr-dudtr" id="dudtr-dudtr" placeholder="Email address"/>

<input name="" type="submit" value="Go">
</form>

            <div id="contact-details">
            Call +61 2 9986 0955<br>
			email <a href="mailto:info@becentre.org.au" target="_blank">info@becentre.org.au</a></div>
            <div class="clear"></div>
          </div>
          <!--Copyrights-->
          <div id="copyrights">
            <div id="legal"><a href="<?php echo site_url(); ?>/legal">Legal</a> &nbsp;|&nbsp; <a href="<?php echo site_url(); ?>/privacy-policy">Privacy Policy</a>  &nbsp;|&nbsp; <a href="<?php echo site_url(); ?>/security-policy">Security Policy</a> &nbsp;|&nbsp; <a href="<?php echo site_url(); ?>/refund-policy">Refund Policy</a>  </div>
            <div id="signature">Design by <a href="http://www.squadink.com/" target="_blank">Squad Ink</a>. Web development by <a href="http://www.harmonicnewmedia.com/" target="_blank">Harmonic New Media</a>.</div>
            <div class="clear"></div>
          </div>
        </div>
      </footer>
    </div>
  </div>
  <script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-40150030-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</body>
</html>
