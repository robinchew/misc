<?php

$url = $_POST["url"];
$url = "https://au.ewaygateway.com/Request/?" . str_replace("&comment=&=Send Donation&false", "", $url);
$url = str_replace(" ", "%20", $url);	

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

if (CURL_PROXY_REQUIRED == 'True') {
    $proxy_tunnel_flag = (defined('CURL_PROXY_TUNNEL_FLAG') && strtoupper(CURL_PROXY_TUNNEL_FLAG) == 'FALSE') ? false : true;
    curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, $proxy_tunnel_flag);
    curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
    curl_setopt($ch, CURLOPT_PROXY, CURL_PROXY_SERVER_DETAILS);
}

$content = curl_exec($ch);

curl_close($ch);


$xml = simplexml_load_string($content);

if ($xml->Result == "True") {
    echo $xml->URI;
} else {
    echo "false";
}
?>